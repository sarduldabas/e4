# Committee Report Assistant: front-end prototype (COE4)

React 18 + Vite, no backend. All content is mock data in `src/data.js`.

```
npm install
npm run dev      # development
npm run build    # single self-contained dist/index.html
```

Structure
- `src/App.jsx`: state, stage navigation, change propagation (brief -> analysis -> slides)
- `src/components/StageBrief.jsx`, `StageAnalysis.jsx`, `StageReport.jsx`: the three stages
- `src/components/Charts.jsx`, `Slide.jsx`: SVG charts and the 960x540 slide renderer
- `src/components/Overlays.jsx`: versions drawer, share dialog, design notes (demo layer)
- `src/workspace.js`: workspace state, smart-chip detection, brief strength
- `src/styles.css`: design tokens and all styles (colors, type scale at the top)

Where the backend plugs in (search for these)
- Voice: simulated in `StageBrief.jsx` (`startVoice`). Replace with Azure Speech or the Web Speech API.
- File extraction: `addReal` / `addSample` in `StageBrief.jsx`.
- Analysis run: `RunView` in `StageAnalysis.jsx` (timer now; later stream agent events).
- Section content and citations: `SECTIONS` and `SOURCES` in `data.js`.
- Slide generation: `buildSlides` in `data.js`. PPTX export is mocked in `StageReport.jsx`.
