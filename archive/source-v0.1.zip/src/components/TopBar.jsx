import { Check, ChevronDown, History, Share2, Lock, LayoutGrid } from 'lucide-react';
import { Avatars } from './ui.jsx';
import { briefStrength, includedSections } from '../workspace.js';

export function Brand({ onClick }) {
  return (
    <button className="brand" onClick={onClick} aria-label="Committee Report Assistant home">
      <span className="brand-mark" aria-hidden="true"><i /><i /><i /></span>
      <span className="brand-name">Committee Report Assistant</span>
    </button>
  );
}

const STEPS = [
  { n: 1, label: 'Brief', sub: 'Tell me what you know' },
  { n: 2, label: 'Analysis', sub: 'Check what I found' },
  { n: 3, label: 'Report', sub: 'Shape the slides' },
];

function caption(n, ws) {
  if (n === 1) return `${briefStrength(ws.brief)}% brief strength`;
  if (n === 2) {
    const a = ws.analysis;
    if (a.status === 'idle') return 'Not started';
    if (a.status === 'running') return 'Analysing…';
    const secs = includedSections(ws);
    return `${secs.filter((s) => a.reviewed[s.id]).length} of ${secs.length} reviewed`;
  }
  const d = ws.deck;
  if (d.status === 'idle') return 'Not started';
  if (d.status === 'building') return 'Building…';
  return `${d.slides.length} slides`;
}

export function TopBar({ ws, stage, canGo, onStage, onHome, onVersions, onShare }) {
  return (
    <header className="topbar">
      <div className="topbar-in">
        <div className="tb-left"><Brand onClick={onHome} /></div>

        <nav className="stepper" aria-label="Progress">
          {STEPS.map((s, i) => {
            const state = stage === s.n ? 'current' : canGo(s.n) && (s.n < stage || (s.n === 2 && ws.analysis.status === 'done') || (s.n === 3 && ws.deck.status === 'ready')) ? 'done' : 'todo';
            return (
              <div key={s.n} className="step-wrap">
                {i > 0 && <span className={`step-line${state !== 'todo' || stage > i ? ' on' : ''}`} />}
                <button className={`step ${state}`} disabled={!canGo(s.n)} onClick={() => onStage(s.n)} aria-current={stage === s.n ? 'step' : undefined}>
                  <span className="step-dot">{state === 'done' ? <Check size={14} strokeWidth={2.4} /> : s.n}</span>
                  <span className="step-text">
                    <span className="step-label">{s.label}</span>
                    <span className="step-cap">{stage === s.n ? s.sub : caption(s.n, ws)}</span>
                  </span>
                </button>
              </div>
            );
          })}
        </nav>

        <div className="tb-right">
          <span className="secure" title="Designed to run inside the Volkswagen cloud environment"><Lock size={13} /> Stays in VW environment</span>
          <button className="ghost-pill" onClick={onVersions}><History size={15} /> {ws.version} <span className="muted">· Draft</span> <ChevronDown size={14} /></button>
          <Avatars ids={['kw', 'jm', 'ls']} size={28} />
          <button className="btn sm" onClick={onShare}><Share2 size={15} /> Share</button>
        </div>
      </div>
    </header>
  );
}

export function HomeBar({ onHome }) {
  return (
    <header className="topbar plain">
      <div className="topbar-in">
        <div className="tb-left"><Brand onClick={onHome} /></div>
        <div className="tb-right">
          <span className="secure"><Lock size={13} /> Stays in VW environment</span>
          <span className="who"><span className="who-name">Katrin Weber</span><span className="who-dept">Technical Development</span></span>
          <Avatars ids={['kw']} size={32} />
        </div>
      </div>
    </header>
  );
}

export { LayoutGrid };
