import { useEffect, useMemo, useState } from 'react';
import {
  Play, Download, ArrowLeft, ChevronLeft, ChevronRight, Check, AlertTriangle, RefreshCw, Send, Undo2, X, Loader2, FileText, Info,
} from 'lucide-react';
import { SRC, qcText } from '../data.js';
import { detect, includedSections, reportMeta } from '../workspace.js';
import { ActionBar, Avatar, Modal, SourceIcon, useInterval } from './ui.jsx';
import { Slide, SlideFrame } from './Slide.jsx';

const BUILD_STEPS = ['Mapping 7 sections to the committee template', 'Placing 5 charts and the options table', 'Writing speaker notes', 'Checking every figure against the analysis'];
const shorten = (b) => { const cut = b.search(/[;,(]| – | — /); return cut > 38 ? `${b.slice(0, cut).trim().replace(/[.,;:]$/, '')}.` : b; };

function BuildView({ onBuilt }) {
  const [step, setStep] = useState(0);
  useInterval(() => setStep((s) => s + 1), 700, step <= BUILD_STEPS.length);
  useEffect(() => { if (step > BUILD_STEPS.length) { const t = setTimeout(onBuilt, 300); return () => clearTimeout(t); } return undefined; }, [step]); // eslint-disable-line
  return (
    <div className="stage stage-build">
      <header className="stage-head center">
        <p className="eyebrow">Step 3 of 3 · Report</p>
        <h1 className="display lg">Composing your <em>slides.</em></h1>
        <p className="lede">Everything you reviewed goes into the committee template. Each slide stays linked to its analysis section.</p>
      </header>
      <div className="build-grid">
        <ol className="run-steps">
          {BUILD_STEPS.map((t, i) => (
            <li key={t} className={i < step ? 'done' : i === step ? 'active' : 'todo'}>
              <span className="rs-ico">{i < step ? <Check size={14} strokeWidth={2.6} /> : i === step ? <Loader2 size={14} className="spin" /> : <span className="dot" />}</span>
              <span className="rs-main"><strong>{t}</strong></span>
            </li>
          ))}
        </ol>
        <div className="skeletons">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="skel" style={{ animationDelay: `${i * 0.12}s` }} />)}</div>
      </div>
    </div>
  );
}

function Present({ slides, ctx, start, onClose }) {
  const [i, setI] = useState(start);
  useEffect(() => {
    const k = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight' || e.key === ' ') setI((x) => Math.min(slides.length - 1, x + 1));
      if (e.key === 'ArrowLeft') setI((x) => Math.max(0, x - 1));
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [slides.length, onClose]);
  return (
    <div className="present" onClick={() => setI((x) => Math.min(slides.length - 1, x + 1))}>
      <button className="iconbtn light" onClick={(e) => { e.stopPropagation(); onClose(); }} aria-label="Exit presentation"><X size={20} /></button>
      <div className="present-slide"><SlideFrame><Slide slide={slides[i]} ctx={{ ...ctx, n: i + 1 }} /></SlideFrame></div>
      <p className="present-hint">{i + 1} / {slides.length} · Arrow keys to move · Esc to close</p>
    </div>
  );
}

function ExportModal({ onClose, ws, toast }) {
  const [fmt, setFmt] = useState('pptx');
  const [notes, setNotes] = useState(true);
  const [appendix, setAppendix] = useState(true);
  const [state, setState] = useState('idle');
  const [pct, setPct] = useState(0);
  useInterval(() => setPct((p) => { if (p >= 100) { setState('done'); return 100; } return p + 8; }), 120, state === 'running');
  const name = `Committee_report_FAKOM_2026-12-03_${ws.version}.${fmt}`;
  return (
    <Modal title="Export presentation" onClose={onClose} width={520}
      footer={state === 'done'
        ? <><span className="grow" /><button className="btn primary" onClick={() => { toast('Export ready. In the full product the file downloads here.'); onClose(); }}>Done</button></>
        : <><span className="grow" /><button className="btn quiet" onClick={onClose}>Cancel</button><button className="btn primary" disabled={state === 'running'} onClick={() => { setState('running'); setPct(0); }}>{state === 'running' ? 'Creating file…' : 'Export'}</button></>}>
      {state === 'idle' && (
        <div className="export">
          <div className="seg" role="radiogroup" aria-label="Format">
            {[['pptx', 'PowerPoint'], ['pdf', 'PDF']].map(([k, l]) => <button key={k} role="radio" aria-checked={fmt === k} className={fmt === k ? 'on' : ''} onClick={() => setFmt(k)}>{l}</button>)}
          </div>
          <label className="check"><input type="checkbox" checked={notes} onChange={(e) => setNotes(e.target.checked)} /> Include speaker notes</label>
          <label className="check"><input type="checkbox" checked={appendix} onChange={(e) => setAppendix(e.target.checked)} /> Add source appendix (10 sources)</label>
          <p className="muted small">File name: {name}. Version {ws.version} stays editable until you mark it as presented.</p>
        </div>
      )}
      {state !== 'idle' && (
        <div className="export">
          <div className="run-bar"><i style={{ width: `${pct}%` }} /></div>
          <p>{state === 'done' ? <><Check size={16} className="ok" /> {name} is ready.</> : 'Placing charts and applying the template…'}</p>
          {state === 'done' && <p className="muted small">Prototype note: file generation runs in the backend (python-pptx or Open XML) in the full product.</p>}
        </div>
      )}
    </Modal>
  );
}

export default function StageReport({ ws, setDeck, onBuilt, updateSlides, gotoAnalysis, onBack, toast }) {
  const d = ws.deck;
  const a = ws.analysis;
  const [present, setPresent] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [cmd, setCmd] = useState('');
  const [busy, setBusy] = useState(false);
  const [log, setLog] = useState([]);

  const qc = qcText(a.qualCost);
  const det = detect(ws.brief);
  const { committee, dateIso } = reportMeta(ws);
  const slide = d.slides[d.active];
  const ctx = (n) => ({ qc, committee, date: dateIso, n });

  useEffect(() => {
    const k = (e) => {
      const t = e.target;
      if (t.isContentEditable || ['INPUT', 'TEXTAREA'].includes(t.tagName)) return;
      if (e.key === 'ArrowRight') setDeck((x) => ({ ...x, active: Math.min(x.slides.length - 1, x.active + 1) }));
      if (e.key === 'ArrowLeft') setDeck((x) => ({ ...x, active: Math.max(0, x.active - 1) }));
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [setDeck]);

  const patchSlide = (id, patch) => setDeck((x) => ({ ...x, slides: x.slides.map((s) => (s.id === id ? { ...s, ...patch } : s)) }));

  const assist = (text) => {
    const t = (text ?? cmd).trim();
    if (!t || busy || !slide) return;
    setCmd(''); setBusy(true);
    const prev = { id: slide.id, bullets: slide.bullets, notes: slide.notes, title: slide.title };
    setTimeout(() => {
      if (/short|trim|concise|kürz/i.test(t)) patchSlide(slide.id, { bullets: slide.bullets.map(shorten) });
      else if (/note/i.test(t)) patchSlide(slide.id, { notes: `Talking points: ${slide.bullets.join(' ')}` });
      else if (/conclusion|title/i.test(t)) patchSlide(slide.id, { title: slide.title.replace(/[.]$/, '') });
      setLog((l) => [{ text: t, n: d.active + 1, prev, id: Math.random() }, ...l].slice(0, 3));
      setBusy(false);
    }, 1100);
  };
  const undo = (entry) => { patchSlide(entry.prev.id, { bullets: entry.prev.bullets, notes: entry.prev.notes, title: entry.prev.title }); setLog((l) => l.filter((x) => x.id !== entry.id)); };

  const checks = useMemo(() => {
    const secs = includedSections(ws);
    const out = [];
    const usesQc = d.slides.some((s) => ['s1', 's4', 's7'].includes(s.sectionId));
    if (a.qualCost === null && usesQc) out.push({ k: 'warn', t: 'Qualification cost shows a range (€14.2–15.1M) because the conflict is open.', act: 'Resolve in Analysis', go: 's4' });
    else out.push({ k: 'ok', t: 'All figures match the analysis.' });
    const unrev = secs.filter((s) => !a.reviewed[s.id]).length;
    if (unrev) out.push({ k: 'warn', t: `${unrev} of ${secs.length} sections are not reviewed yet.`, act: 'Review', go: secs.find((s) => !a.reviewed[s.id])?.id });
    else out.push({ k: 'ok', t: 'All sections reviewed.' });
    if (a.gap === null) out.push({ k: 'info', t: 'Capacity beyond 2029 is still an open gap (slide 4).', act: 'Resolve in Analysis', go: 's3' });
    const long = d.slides.filter((s) => s.bullets.length > 5 || s.title.length > 140);
    out.push(long.length ? { k: 'warn', t: `${long.length} slide(s) exceed template limits.` } : { k: 'ok', t: 'Text length within template limits.' });
    out.push({ k: 'ok', t: 'Every content slide links to its sources.' });
    return out;
  }, [ws, d.slides, a]);
  const warnCount = checks.filter((c) => c.k === 'warn').length;

  if (d.status === 'building') return <BuildView onBuilt={onBuilt} />;
  if (!slide) return null;

  const stale = d.staleSections.length;
  const staleSlides = d.slides.filter((s) => d.staleSections.includes(s.sectionId));
  const jonasAt = d.slides.findIndex((s) => s.id === 'sl-s4a');

  return (
    <div className="stage stage-report">
      <header className="stage-head compact">
        <div>
          <p className="eyebrow">Step 3 of 3 · Report</p>
          <h1 className="display md">Make it yours, <em>then present.</em></h1>
        </div>
        <div className="expect narrow">
          <div><span className="expect-k">From you</span><span>Edit text directly, ask for changes, resolve the checks.</span></div>
          <div><span className="expect-k">Then</span><span>Export, or present from here.</span></div>
        </div>
      </header>

      {stale > 0 && (
        <div className="banner">
          <RefreshCw size={18} />
          <div><strong>The analysis changed after these slides were built</strong><span>{staleSlides.length} slide{staleSlides.length === 1 ? '' : 's'} affected. Slides you edited by hand elsewhere stay untouched.</span></div>
          <button className="btn primary sm" onClick={() => { updateSlides(); toast('Slides updated'); }}>Update slides</button>
        </div>
      )}

      <div className="rep-grid">
        <aside className="rail" aria-label="Slides">
          {d.slides.map((s, i) => (
            <button key={s.id} className={`thumb${i === d.active ? ' on' : ''}`} onClick={() => setDeck({ active: i })} aria-label={`Slide ${i + 1}`}>
              <span className="t-n">{i + 1}</span>
              <span className="t-frame"><SlideFrame><Slide slide={s} ctx={ctx(i + 1)} /></SlideFrame></span>
              {i === jonasAt && <span className="t-pres"><Avatar id="jm" size={20} /></span>}
              {d.staleSections.includes(s.sectionId) && <span className="t-stale" title="Needs update" />}
            </button>
          ))}
        </aside>

        <main className="canvas-col">
          <div className="canvas-bar">
            <span className="tpl"><FileText size={14} /> {det.template || 'Committee template'}</span>
            <span className="grow" />
            <button className="iconbtn" disabled={d.active === 0} onClick={() => setDeck({ active: d.active - 1 })} aria-label="Previous slide"><ChevronLeft size={18} /></button>
            <span className="small muted">Slide {d.active + 1} of {d.slides.length}</span>
            <button className="iconbtn" disabled={d.active === d.slides.length - 1} onClick={() => setDeck({ active: d.active + 1 })} aria-label="Next slide"><ChevronRight size={18} /></button>
          </div>
          <div className="canvas">
            <SlideFrame key={slide.id}>
              <Slide slide={slide} ctx={ctx(d.active + 1)} editable onEdit={(p) => patchSlide(slide.id, p)} />
            </SlideFrame>
          </div>
          <p className="canvas-hint"><Info size={13} /> Click any text on the slide to edit it.</p>
          {slide.sources?.length > 0 && (
            <div className="slide-src">
              <span className="muted small">Sources on this slide</span>
              {slide.sources.map((n) => <span key={n} className="src-pill" title={SRC[n].excerpt}><SourceIcon kind={SRC[n].kind} size={13} /> {SRC[n].name}</span>)}
            </div>
          )}
        </main>

        <aside className="panel">
          <section className="card pad">
            <h2>Ask for a change</h2>
            <form className="chat-in" onSubmit={(e) => { e.preventDefault(); assist(); }}>
              <input value={cmd} onChange={(e) => setCmd(e.target.value)} placeholder={`Slide ${d.active + 1}: what should change?`} aria-label="Ask for a change to this slide" />
              <button className="round solid sm" aria-label="Send" disabled={busy}><Send size={15} /></button>
            </form>
            <div className="chips">{['Shorten the text', 'Add speaker notes', 'Make the title a conclusion'].map((t) => <button key={t} className="opt" onClick={() => assist(t)}>{t}</button>)}</div>
            {busy && <p className="working"><Loader2 size={14} className="spin" /> Updating slide {d.active + 1}…</p>}
            {log.map((l) => <p key={l.id} className="logline"><Check size={13} className="ok" /> Slide {l.n}: “{l.text}” <button className="textlink" onClick={() => undo(l)}><Undo2 size={12} /> Undo</button></p>)}
          </section>

          <section className="card pad">
            <div className="card-head"><h2>Checks</h2><span className={`pill ${warnCount ? 'warn' : 'good'}`}>{warnCount ? `${warnCount} to look at` : 'All clear'}</span></div>
            <ul className="checks">
              {checks.map((c, i) => (
                <li key={i} className={c.k}>
                  {c.k === 'ok' ? <Check size={15} /> : <AlertTriangle size={15} />}
                  <span>{c.t}{c.act && <> <button className="textlink" onClick={() => gotoAnalysis(c.go)}>{c.act}</button></>}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="card pad">
            <h2>Speaker notes <span className="muted small">· slide {d.active + 1}</span></h2>
            <textarea className="notes" value={slide.notes || ''} onChange={(e) => patchSlide(slide.id, { notes: e.target.value })} placeholder="What you want to say on this slide" aria-label="Speaker notes" rows={4} />
          </section>
        </aside>
      </div>

      <ActionBar>
        <div className="ab-text"><strong>{warnCount ? `${warnCount} check${warnCount > 1 ? 's' : ''} to look at` : 'Ready to export'}</strong><span>You can export now and return to change anything. Version {ws.version} stays a draft.</span></div>
        <button className="btn quiet" onClick={onBack}><ArrowLeft size={16} /> Analysis</button>
        <button className="btn" onClick={() => setPresent(true)}><Play size={15} /> Present</button>
        <button className="btn primary lg" onClick={() => setExporting(true)}><Download size={17} /> Export</button>
      </ActionBar>

      {present && <Present slides={d.slides} ctx={ctx(1)} start={d.active} onClose={() => setPresent(false)} />}
      {exporting && <ExportModal ws={ws} onClose={() => setExporting(false)} toast={toast} />}
    </div>
  );
}
