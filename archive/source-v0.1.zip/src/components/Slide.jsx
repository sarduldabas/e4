import { useLayoutEffect, useRef, useState } from 'react';
import { CapacityChart, CostChart, PriceChart, RiskMatrix, Gantt, OptionsTable, riskLevel } from './Charts.jsx';
import { RISKS, fmtDate } from '../data.js';

/** Scales a fixed 960x540 slide to whatever width its container has. */
export function SlideFrame({ children, className = '' }) {
  const ref = useRef(null);
  const [w, setW] = useState(960);
  useLayoutEffect(() => {
    const el = ref.current;
    setW(el.getBoundingClientRect().width || 960);
    const ro = new ResizeObserver(([e]) => setW(e.contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return (
    <div ref={ref} className={`frame ${className}`} style={{ height: (w * 9) / 16 }}>
      <div className="frame-in" style={{ transform: `scale(${w / 960})` }}>{children}</div>
    </div>
  );
}

function Ed({ as: Tag = 'div', value, editable, onCommit, className }) {
  if (!editable) return <Tag className={className}>{value}</Tag>;
  return (
    <Tag
      className={`${className || ''} editable`} contentEditable suppressContentEditableWarning spellCheck={false}
      onBlur={(e) => { const t = e.currentTarget.textContent.trim(); if (t !== value) onCommit(t); }}
    >
      {value}
    </Tag>
  );
}

export function Slide({ slide, ctx, editable = false, onEdit = () => {} }) {
  const { qc, committee, date, n } = ctx;
  const bullets = (cls = '') => (
    <ul className={`sl-bullets ${cls}`}>
      {slide.bullets.map((b, i) => (
        <Ed as="li" key={`${slide.id}-${i}-${b}`} value={b} editable={editable} onCommit={(t) => onEdit({ bullets: slide.bullets.map((x, k) => (k === i ? t : x)).filter(Boolean) })} />
      ))}
    </ul>
  );

  if (slide.layout === 'title') {
    return (
      <div className="slide sl-cover">
        <div className="cover-bar" />
        <p className="cover-kicker">{committee} · Committee report</p>
        <Ed as="h1" className="cover-title" value={slide.title} editable={editable} onCommit={(t) => onEdit({ title: t })} />
        <p className="cover-sub">{slide.sub}</p>
        <p className="cover-foot">Confidential · For committee use only</p>
      </div>
    );
  }

  return (
    <div className={`slide sl-${slide.layout}`}>
      <div className="sl-top"><span>{committee} · {fmtDate(date)}</span><i /></div>
      <Ed as="h2" className="sl-title" value={slide.title} editable={editable} onCommit={(t) => onEdit({ title: t })} />
      <div className="sl-body">
        {slide.layout === 'summary' && (
          <>
            {bullets()}
            {slide.decision && <div className="sl-decision"><b>Decision requested</b><span>{slide.decision.replace('Decision requested: ', '')}</span></div>}
          </>
        )}
        {slide.layout === 'text' && bullets('wide')}
        {slide.layout === 'capacity' && (<>{bullets('half')}<div className="sl-chart"><CapacityChart /></div></>)}
        {slide.layout === 'table' && <div className="sl-wide"><OptionsTable qc={qc} /></div>}
        {slide.layout === 'charts' && (<><div className="sl-chart"><CostChart /></div><div className="sl-chart"><PriceChart /></div></>)}
        {slide.layout === 'risk' && (
          <>
            <div className="sl-chart narrow"><RiskMatrix /></div>
            <ul className="sl-risks">
              {RISKS.map((r) => <li key={r.id}><b>{r.id}</b><span>{r.name}</span><em className={riskLevel(r).toLowerCase()}>{riskLevel(r)}</em></li>)}
            </ul>
          </>
        )}
        {slide.layout === 'timeline' && (<div className="sl-wide"><Gantt />{bullets('small')}</div>)}
      </div>
      <div className="sl-foot"><span>Confidential · For committee use only</span><span>{n}</span></div>
    </div>
  );
}
